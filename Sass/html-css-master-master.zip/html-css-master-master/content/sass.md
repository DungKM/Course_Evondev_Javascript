# Sass

- **sass**: sẽ có 2 đuôi mở rộng của file là `.scss` hoặc .sass( ko dùng dấu {})
- Cài đặt sass với lệnh `npm install -g sass`
- Lệnh để chạy sass: `sass path-of-sass-file path-of-css-file --watch`
- _nested_: lồng nhau
- .header-item, .header-link, .header-top, .header-bottom
<!-- .header {
  code của class .header
  &-item{
    code của class .header-item
  }
} -->
- _variables_: $primary-color: red;
- color: $primary-color;
- _@import_
- _pattern 7-1_
- _mixins_
- _loop_
- _if_
- _else_
