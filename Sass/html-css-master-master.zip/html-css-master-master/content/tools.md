# VScode settings

- Font size: 13
- Font family: SF Mono
- Line height: 30
- Letter spacing: 0
- Word wrap: on
- Word wrap column: 100
- Format on save: Tích chọn vào
- Default formatter: Prettier

# VScode commands

- ctrl/cmd + P: Tìm kiếm file trong dự án
- ctrl/cmd + shift + P: Mở các lệnh trong vscode
- ctrl/cmd + D: Chọn nhiều từ giống nhau
- ctrl/cmd + shift + L: Chọn hết nhiều từ giống nhau
- alt/option + mũi tên lên hoặc xuống: Để di chuyển 1 hoặc nhiều dòng khi bôi đen hoặc không
- shift + alt/option + mũi tên lên hoặc xuống: Sao chép nhanh

# Chrome extensions

- VisBug
- Dimensions
- Ejoy English
- Eye Dropper
- Color Slurp

# Desktop apps

- Hướng dẫn chụp màn hình với snipping-tools, monosnap
